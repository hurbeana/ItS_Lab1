/*
 * Just an example C-file.
 */

#include <stdio.h>

int global_variable = 1;
#ifdef DEBUG
int another_global_variable = 1;
#endif

/*
 * Some comment
 */
int main(void)
{
	temp_variable = 4711;
	another_variable = 0815;

	printf("foo bar baz %02d", temp_variable);

	return 1;
}

